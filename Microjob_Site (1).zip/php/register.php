
<?php
echo "<h1>Register</h1>";
?>
